# Psyberduck
#TECHNOMANCERS
Team Members
*Gagan kumar soni
*Garima pandey
*Swayam gupta
*Akshita gupta

live deployment link of netlify :- https://goodifie.netlify.app/

Theme 1: You plan to start an essentials delivery system. Develop an
App or a Website where people can order the listed essential goods &
delivery partners can deliver the same to the mentioned locations.

Our website Goodifie has been built on the above mentioned theme to provide essentials goods according to the needs of our customers.
Technologies that has been used to make this website are HTML, CSS, Bootstrap, JS, Node JS, Express JS, MySQL, Netlify and Heroku . It provides an intuitive UI to make our products more appealing to the customers with an interactive Home Screen, Login and Signup Window, Categories Catalogue to browse through the various items, and finally the Cart to add as many items as the user wishes !
In backend, we are using Model View Conroller(MVC) Architecture. And in front-end, we are using component-tree structure with vue js.


We are still working on the following functionalities: 
1. A user can place the order after adding an address.
2. A user can view his previous orders in the orders page.
3. A user can filter the orders according to maximum discounts, price and category.
4. And many more!!!

#Thank You.
